import { ICartTotal } from 'models';

const mockTotal: ICartTotal = {
  productQuantity: 1,
  installments: 1,
  totalPrice: 1099,
  currencyId: 'IND',
  currencyFormat: '₹',
};

export default mockTotal;
